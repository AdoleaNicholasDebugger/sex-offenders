
<!DOCTYPE html>
<html ><head>
  
  
 <script language='JavaScript' type='text/JavaScript'>
<!--
function validate() {
	if(document.form1.Reg_No.value=='')
        
		{
		alert('Please input name');
		return false;
		}
		
		if(document.form1.comment.value=='')
        
		{
		alert('Please input a comprehensive report');
		return false;
		}
	if(document.form1.Class.value=='')
        
		{
		alert('Please input the Class');
		return false;
		}
	else	{
		return true;
			}
}
//-->
</script> 
  
  <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">

  
    <meta charset="UTF-8">
   
	
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="css/normalize.css">

    
        <link rel="stylesheet" href="css/style.css">

    
    
    
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"><style type="text/css">
<!--
body {
	background-color: #FF9999;
}
.style1 {color: #FF9999}
.style2 {
	font-family: "Times New Roman", Times, serif;
	font-weight: bold;
	color: #0000FF;
}
.style3 {color: #FF3333}
-->
  </style></head>

  <body>

    
  <div class="container">
  <div class="row header">
   
  </div>
  <div class="row body">
   <form id="form1" name="form1" action="whistleProcessor.php" method="post" enctype="multipart/form-data" onSubmit='return validate();'>
      <ul>
        
        <li>
          
          </p>
		  <p class="left">
            <label for="Reg_No">Name/Ananimous</label>
		    <input type="text" name="Reg_No" placeholder="e.g Bishop-Grace" />
		  </p>
		   <p class="pull-left">
            <label for="last_name"></label>
	      </p>
        
          <p class="left">&nbsp;</p>
		   <p class="pull-left">
            <label for="Reg_No">EVIDENCE(picture/text/video(max of 500kb) </label>
           <input type="file" name="photo" />
          </p>
		  <label for="comment"></label>
		   <p>
		   <label for="Reg_No">Detail Report</label>
		   <textarea type="text" name="comment" placeholder="see something-   
		   say something" /> </textarea>
		    </p>
        </li>        
        <li><div class="divider"></div></li>
        
        <li>
          <input class="btn btn-submit" type="submit" value="Submit" name ="btn-upload" />
          <small>or press <strong>enter</strong></small> <span class="style3">&lt;&lt;</span><span class="style2"><a href="../home/index.html">Home Page</a></span><span class="style3">&lt;&lt;</span> </li>
      </ul>
    </form> 
	 
  </div>
</div>
    
    
    
    
    
  </body>
</html>
