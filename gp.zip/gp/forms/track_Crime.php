
<?php


error_reporting(E_ALL ^ E_NOTICE);


?>




<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">

<?php


error_reporting(E_ALL ^ E_NOTICE);


?>


<!DOCTYPE html>

<html >
  <head>
 
 <script language='JavaScript' type='text/JavaScript'>
<!--
function validate() {
	if(document.form1.candidate.value=='')
        
		{
		alert('Please input the candidate-name');
		return false;
		}
		
	else	{
		return true;
			}
}
//-->
</script> 
  
  <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">

  
    <meta charset="UTF-8">
    <title>NACOSS</title>
	
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="css/normalize.css">

    
        <link rel="stylesheet" href="css/style.css">

    
    
    
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"><style type="text/css">
<!--
body {
	background-color: #FF9999;
}
.style1 {color: #FF9999}
-->
  </style></head>

  <body>

    
  <div class="container">
  <div class="row header">
    <img src="logo.jpg" height="25%" width="106%">
    <h3> .........Track Criminals </h3>
  </div>
  <div class="row body">
   <form id="form1" name="form1" action="candidatesprocessor.php" method="post" enctype="multipart/form-data" onSubmit='return validate();'>
      <ul>
        
        <li>
		 <p class="left">
		  <label for="UserName">Select Status </label>
		  <select name="post" >
            <option>select</option>
            <option>Citizen</option>
            <option>Foreigner</option>
                     </select>
		 </p>
          <p class="right">
            <label for="Password">Suspect's Name</label>
            <input type="text" name="candidate"  />
          </p>
        </li>        
       
          <input class="btn btn-submit" type="submit" value="Track" name ="btn-upload" /></li>
      </ul>
    </form> 
	 
  </div>
</div>
    
    
    
    
    
  </body>
</html>

<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
<title>NACOSS e-Voting</title>

