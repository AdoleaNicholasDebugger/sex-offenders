<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>NIMC</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<script language='JavaScript' type='text/JavaScript'>
<!--
function validate() {
	if(document.form1.query.value=='')
		{
		alert('input BVN_No');
		return false;
		}
          else	{
		return true;
			}
}
//-->



</script>
<style type="text/css">
<!--
.style1 {
	color: #FF9999;
	font-weight: bold;
}
.style4 {color: #990000; font-weight: bold; }
.style5 {color: #FF0000}
-->
</style>
</head>
<body>
<img src="../images/logo.jpg">
<div>
*********************************************
</div>
 <form method="Post" action="stationdocu.php" name="form1" onSubmit='return validate();'>
    <label><font color="BLUE"><B>Enter NIMC.No*</font> </label><input type="text" name="query" />
<input type="submit" name="submit" value="Search" />
</form></td>
<div id="body"></div>
</body>
</html>