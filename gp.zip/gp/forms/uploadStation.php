<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
<title>npf</title>
<?php
include '../config/dbconfig.php';


?>
<?php

error_reporting(E_ALL ^ E_NOTICE);
 //This is the directory where images will be saved
 $target = "images/";
 $target = $target . basename( $_FILES['photo']['name']);

 //This gets all the other information from the form
 
 
$Stationcode=$_POST['Stationcode'];
 $Division=$_POST['Division'];
 $SuspectAddress=$_POST['SuspectAddress']; 
 $bio=$_POST['bio'];
$CaseIPO=$_POST['CaseIPO'];
  $Report=$_POST['Report'];
 $charges=$_POST['charges'];
  $CrimeType=$_POST['CrimeType'];
 $pic=($_FILES['photo']['name']);
 $dat=date('m/d/Y H:i:s', 1299446702);;
 
 if($CrimeType=="Murder") {

$names= 0;

$result =  mysqli_query($db,"SELECT count FROM graph where category ='Murder'");
while ($row = mysqli_fetch_array($result)) {
 $names = $row['count'];  
$names=$names+1; 
   
   
   mysqli_query($db,"UPDATE graph SET count=$names WHERE category ='Murder' ");

   
} 

 
  }
 
//************************************************************************************************************************
if($CrimeType=="Militancy") {

// Connect to server and select databse.

	
 
$names = 0;
$result = mysqli_query($db,"SELECT count FROM graph where category ='Militancy'");
while ($row = mysqli_fetch_array($result)) {
 $names = $row['count'];  
$names=$names+1; 
   
   
   mysqli_query($db,"UPDATE graph SET count=$names WHERE category ='Militancy' ");


   
} 

 
  }
 
//*8888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888
if($CrimeType=="Robbery") {



 
$names = 0;
$result = mysqli_query($db,"SELECT count FROM graph where category ='Robbery'");
 while ($row = mysqli_fetch_array($result)) {
 $names = $row['count'];  
$names=$names+1; 
   
   
   mysqli_query($db,"UPDATE graph SET count=$names WHERE category ='Robbery' ");


   
} 

 
  }
 
//*****************************************************************************************************************************
if($CrimeType=="Rape") {


 
$names = 0;
$result =  mysqli_query($db,"SELECT count FROM graph where category ='Rape'");
while ($row = mysqli_fetch_array($result)) {
 $names = $row['count'];  
$names=$names+1; 
   
   
   mysqli_query($db,"UPDATE graph SET count=$names WHERE category ='Rape' ");
 

   
} 

 
  }
 
//_____________________________________________________________________________________________________________________
 //*****************************************************************************************************************************
if($CrimeType=="Terrorism") {


 
$names = 0;
$result =  mysqli_query($db,"SELECT count FROM graph where category ='Terrorism'");
 while ($row = mysqli_fetch_array($result)) {
 $names = $row['count'];  
$names=$names+1; 
   
   
    mysqli_query($db,"UPDATE graph SET count=$names WHERE category ='Terrorism' ");
 

   
} 

 
  }
 

	
if($_FILES['photo']['size']>50000000)	
{
?>
		<script>
		alert('Image file too large, must be less than 500kb');
        window.location.href='index.html';
        </script>
		<?php
}
elseif($_FILES['photo']['size']<=0)
{
?>
		<script>
		alert('Image file not loaded');
        window.location.href='index.html';
        </script>
		<?php
}
	else
	{
	$query="select * from station_report ";
	$pin=1;
	
	//........................................
	$result=mysqli_query($db,$query);
	
	while ($row = mysqli_fetch_array($result)) {
$pin=$pin+1; 
}

$query="insert into station_report
values('$pin','$Stationcode','$Division','$CaseIPO','$bio','$SuspectAddress','$dat','$Report','$CrimeType','$charges','$pic')";


$result=mysqli_query($db,$query);
//Writes the photo to the server
if($result){
 if(move_uploaded_file($_FILES['photo']['tmp_name'], $target))

?>
		<script>
		alert('successfully uploaded');
        window.location.href='../admin/admindashboard.php';
        </script>
		<?php
	}
	else
	{
		?>
		<script>
		alert('error while uploading file');
        window.location.href='../admin/admindashboard.php?fail';
        </script>
		<?php
	}
	}

 ?>