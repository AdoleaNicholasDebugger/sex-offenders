<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">

<?php
session_start();

error_reporting(E_ALL ^ E_NOTICE);


?>

<?php
if(!isset($_SESSION['password']))
{
header("Location:../admin/login.html"); 
die();
}
?>
<!DOCTYPE html>

<html >
  <style type="text/css">
<!--
.style2 {color: #990000}
-->
  </style>
  <head>
 
 <script language='JavaScript' type='text/JavaScript'>
<!--
function validate() {
	if(document.form1.UserName.value=='')
        
		{
		alert('Please input the user-name');
		return false;
		}
		if(document.form1.Password.value=='')
        
		{
		alert('Please input the password');
		return false;
		}
		
	else	{
		return true;
			}
}
//-->
</script> 
  
  <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">

  
    <meta charset="UTF-8">
    <title>NACOSS</title>
	
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="css/normalize.css">

    
        <link rel="stylesheet" href="css/style.css">

    
    
    
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"><style type="text/css">
<!--
body {
	background-color: #999999;
}
-->
  </style></head>

  <body>

    
  <div class="container">
  <div class="row header">
    <h1><img src="logo.jpg" width="380" height="100">&nbsp;</h1>
    
  </div>
  <div class="row body">
   <form id="form1" name="form1" action="assignpassprocessor.php" method="post" enctype="multipart/form-data" onSubmit='return validate();'>
      <ul>
        
        <li>
		
		  <label for="UserName"><span class="style2">User Name*</span></label>
		    <input type="text" name="UserName"  />
		 </p>
          
            <label for="Password"><span class="style2">Password*</span></label>
            <input type="Password" name="Password"  />
          </p>
        </li>        
       
          <input class="btn btn-submit" type="submit" value="create" name ="btn-upload" />
          <small>or press <strong>enter to create account</strong></small>        </li>
      </ul>
    </form> 
	 
  </div>
</div>
    
    
    
    
    
</body>
</html>

<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
<title>NACOSS e-Voting</title>

