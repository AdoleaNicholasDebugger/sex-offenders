<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
<title>NACOSS e-Voting</title>
<?php
include '../config/dbconfig.php';
?>
<?php

error_reporting(E_ALL ^ E_NOTICE);
 //This is the directory where images will be saved
 $target = "images/";
 $target = $target . basename( $_FILES['photo']['name']);

 //This gets all the other information from the form


 $FirstName=$_POST['FirstName'];
 $OtherNames=$_POST['OtherNames'];
 $CrimeCharges=$_POST['CrimeCharges'];
 $pic=($_FILES['photo']['name']);
 

//Connects to your Database
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');
	
if($_FILES['photo']['size']>500000)	
{
?>
		<script>
		alert('Image file too large, must be less than 500kb');
        window.location.href='index.html';
        </script>
		<?php
}
elseif($_FILES['photo']['size']<=0)
{
?>
		<script>
		alert('Image file not loaded');
        window.location.href='index.html';
        </script>
		<?php
}
	else
	{
	$query="select * from wanted ";
	$pin=1;
	
	//........................................
	$result=mysql_query($query);
	
	while ($row = mysql_fetch_array($result)) {
$pin=$pin+1; 
}

$query="insert into wanted
values('$pin','$FirstName','$OtherNames','$CrimeCharges','$pic')";


$result=mysql_query($query);
//Writes the photo to the server
if($result){
 if(move_uploaded_file($_FILES['photo']['tmp_name'], $target))

?>
		<script>
		alert('successfully uploaded');
        window.location.href='../admin/admindashboard.php';
        </script>
		<?php
	}
	else
	{
		?>
		<script>
		alert('error while uploading file');
        window.location.href='../admin/admindashboard.php?fail';
        </script>
		<?php
	}
	}

 ?>