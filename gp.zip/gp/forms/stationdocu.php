<!-- <img src="../admin/logo.jpg"> -->
<!DOCTYPE html>
<html ><head>
  
  
  
   <link href="http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet">
      <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
      <script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
      <!-- Javascript -->
      <script>
         $(function() {
            $( "#datepicker-13" ).datepicker();
            $( "#datepicker-13" ).datepicker("show");
         });
      </script>
  
  
 
  <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">

  
    <meta charset="UTF-8">
    <title>npf</title>
	
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="css/normalize.css">

    
        <link rel="stylesheet" href="css/style.css">

    
    
    
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"><style type="text/css">
<!--
body {
	background-color: #FFFFFF;
}
.style1 {
	color: #993300;
	font-size: x-large;
}
.style2 {
	font-family: "Times New Roman", Times, serif;
	font-weight: bold;
	color: #0000FF;
}
.style3 {color: #FF3333}
.style10 {color: #990000}
-->
  </style></head>

  <body>

    
  <div class="container">
  <div class="row header">
    <h1><span class="style1">Station Sex Crime Documentation </span></h1>
  </div>
  <div class="row body">
  
  
  <?php
  
  error_reporting(E_ALL ^ E_NOTICE);
	$query=$_POST["query"];
	

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.paystack.co/bank/resolve_bvn/$query",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "Authorization: Bearer sk_live_a3679a6ca5a48cc25e141dca6e2bdd6eff545505",
    "Cookie: __cfduid=d808f1cbbbaf1af163ccc030552b0d05c1597495166; sails.sid=s%3AF9olEUnBC1oh6kdw3PjRxSlS0IN6YTCZ.471txQPsRrVlwIEWVfXC4pTvIx9k2bWHi9irTAFMg2o"
  ),
));

$response = curl_exec($curl);

curl_close($curl);

?>
  
  
  
  
  
   <form id="form1" name="form1" action="uploadStation.php" method="post" enctype="multipart/form-data" onSubmit='return validate();'>
      <ul>
        
        <li>
         
          
		  <p class="right">
            <label for="first_name"><span class="style10">Enter NIMC No:</span></label>
            <input type="text" name="Stationcode" required  />
          </p>
          
		  <p class="right">
            <label for="first_name"><span class="style10">Station code:*</span></label>
            <input type="text" name="Division" required />
          </p>
          <p class="pull-left">
            <label for="last_name"><span class="style10">Suspect Address:</span>*</label>
            <input type="text" name="SuspectAddress" required />      
          </p>
		  
		   <p class="pull-right">
            <label for="last_name"><span class="style10">Suspect Full name*</span></label>
            <input type="text" name="name" required />
    <?php echo $response; ?>
</textarea>
          </p>
        <p class="left">
            <label for="Reg_No"><span class="style10">Case IPO :*</span></label>
            <input type="text" name="CaseIPO" required />
          </p>
		   
		   <p class="left">
            <label for="Reg_No"><span class="style10">Report:*</span></label>
            <textarea cols="50" rows="10" name="Report" required/></textarea>
          </p>
		   <p class="pull-left">
            <label for="last_name"><span class="style10">Charged to Court ?</span>(Yes/No):*</label>
            <select name="charges" >
    <option>----</option>
    <option>Yes</option>
    <option>No</option>
	 
    </select>    
          </p>
         <p class="right">
		  <label for="last_name"><span class="style10">Crime Type</span> </label>
      <select name="CrimeType" >
    <option>----</option>
    
    <option>Other Sexual Offences</option>
	 <option>Rape</option>
	
    </select>
          </p>
		   <p class="pull-left">
            <label for="Reg_No"><span class="style10">suspect photo:(max of 500kb) </span></label>
           <input type="file" name="photo" />
          </p>
        </li>        
        <li><div class="divider"></div></li>
        
        <li>
          <input class="btn btn-submit" type="submit" value="Submit" name ="btn-upload" />
          <small>or press <strong>enter</strong></small></li>
      </ul>
    </form> 
	 
  </div>
</div>
    
    
    
    
    
  </body>
</html>
