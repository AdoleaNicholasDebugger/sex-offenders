<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">

<?php
include '../config/dbconfig.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>NACOSS</title>
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>
<div id="header">
<label>NACOSS e-Voting </label>
</div>
<div id="body">
	
    <br /><br />
    <?php
	
	mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');

	if(isset($_GET['success']))
	{
		?>
        <label>File Uploaded Successfully...  <a href="../home/index.html">Click to exit.</a></label>
        <?php
	}
	else if(isset($_GET['fail']))
	{
		 header("Location:index.html");
	}
	else
	{
		?>
        <label>Try to fill the Form</label>
        <?php
	}
	?>
</div>
<img src="../admin/css/e-learning-250x250.jpg" width="250" height="250">
<div id="footer">
</div>
</body>
</html>