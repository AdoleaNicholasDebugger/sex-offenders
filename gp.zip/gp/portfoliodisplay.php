<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>NPF</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">      
	<link href="css/main.css" rel="stylesheet">
	 <link href="css/responsive.css" rel="stylesheet">
	 <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->   
	<script language='JavaScript' type='text/JavaScript'>    
    function validate() {
	if(document.form1.query.value=='')
		{
		alert('input the Suspect Name');
		return false;
		}
          else	{
		return true;
			}
}
//-->

<?php
include 'config/dbconfig.php'
?>

</script>
  </head>
  <body class="homepage">   
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html">Sex Offenders Database<img src="images/logo.jpg">.</a>
                </div>
				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li ><a href="index.html">Home</a></li>
                        <li><a href="about-us.html">About Us</a></li>
                        <li><a href="contact-us.html">Report Crime</a></li>
                        <li class="active"><a href="portfolio.html">Convicts</a></li>
                       <li><a href="#">News Blog</a></li> 
                                                        
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->
		
    </header><!--/header-->
		
	<section id="portfolio">
        <div class="container">
            <div class="center">
               <h2>Convicts Search Result<img src="crime.jpg" height="60" width="60"></h2>
               *******************************************
            </div>
        
 <div class="row contact-wrap"> 
                <div class="status alert alert-success" style="display: none"></div>
          
<div class="table-responsive text-nowrap">
  
	<table class="table table-striped w-auto" width="80%" border="1" align="center">
	
    <tr>
    <th colspan="8"><span class="style1">Crime Tracking </span><span class="style6">...
     
    </span>
    </tr>
    <tr>
	
	
    <td><span class="style4">caseIPO</span></td>
    
	<td><span class="style4">Crime Date</span></td>
	<td><span class="style4">crimecategory</span></td>
	<td><span class="style4">Details</span></td>
    <td><span class="style4">charged to court?</span></td>
	<td><span class="style4">divisioncode</span></td>
	
    </tr>
    <?php
	
	error_reporting(E_ALL ^ E_NOTICE);
	$query=$_POST["query"];
	

$query=($_GET['query']);

  $sql = mysqli_query($db,"SELECT * FROM station_report WHERE stationcode LIKE '$query%'") or die(mysqli_error());
	

	
	
	while($row=mysqli_fetch_array($sql))
	
	
	{
	
	$caseIPO = $row["caseIPO"]; 
	$Bio = $row["bio"]; 
	$reportdate = $row["reportdate"]; 
	$crimecategory = $row["crimecategory"];
	$crimecategory = $row["report"]; 
	$chargedtocourt = $row["chargedtocourt"]; 
	$divisioncode = $row["divisioncode"]; 
	
	?>
        <tr>
		
        <td><?php echo $row['caseIPO'] ?></td>
      <td><?php echo $row['reportdate'] ?></td>
        <td><?php echo $row['crimecategory'] ?></td>
		<td><?php echo $row['report'] ?></td>
		<td><?php echo $row['chargedtocourt'] ?></td>
        <td><?php echo $row['divisioncode'] ?></td>
        </tr>
        <?php
	}
	?>
    </table>
   
           
                    </div><!--/.portfolio-item-->

                    <div class="portfolio-item joomla bootstrap col-xs-12 col-sm-4 col-md-3">
                             
                    </div><!--/.portfolio-item-->

                    <div class="portfolio-item bootstrap wordpress col-xs-12 col-sm-4 col-md-3">
                        <div class="recent-work-wrap">
                            <img class="img-responsive" src="images/portfolio/recent/item4.png" alt="">
                            <div class="overlay">
                                <div class="recent-work-inner">
                                   
                                    
                                </div> 
                            </div>
                        </div>        
                    </div><!--/.portfolio-item-->

                    
                    

                   
                    </div><!--/.portfolio-item-->

                   
                        </div>          
                    </div><!--/.portfolio-item-->

                    <div class="portfolio-item wordpress html bootstrap col-xs-12 col-sm-4 col-md-3">
                        
                        </div>          
                    </div><!--/.portfolio-item-->
                </div>
            </div>
        </div>
    </section><!--/#portfolio-item-->
	
	<section id="bottom">
        <div class="container wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="widget">
                        
                    </div>    
                </div><!--/.col-md-3-->

                <div class="col-md-3 col-sm-6">
                    <div class="widget">
                       
                    </div>    
                </div><!--/.col-md-3-->

                <div class="col-md-3 col-sm-6">
                    <div class="widget">
                        
                       
                    </div>    
                </div><!--/.col-md-3-->

                <div class="col-md-3 col-sm-6">
                    <div class="widget">
                        
                    </div>    
                </div><!--/.col-md-3-->
            </div>
        </div>
    </section><!--/#bottom-->
	
	<div class="top-bar">
		<div class="container">
			<div class="row">
			    <div class="col-lg-12">
				   <div class="social">
						<ul class="social-share">
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin"></i></a></li> 
							<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
							<li><a href="#"><i class="fa fa-skype"></i></a></li>
						</ul>
				   </div>
                </div>
			</div>
		</div><!--/.container-->
	</div><!--/.top-bar-->
	
	<footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2020 <a target="_blank" href="http://bootstraptaste.com/" title="Free Twitter Bootstrap WordPress Themes and HTML templates">My MSC Project</a>. All Rights Reserved.
                </div>
                <!-- 
                    All links in the footer should remain intact. 
                    Licenseing information is available at: http://bootstraptaste.com/license/
                    You can buy this theme without footer links online at: http://bootstraptaste.com/buy/?theme=Gp
                -->
                <div class="col-sm-6">
                   
                </div>
            </div>
        </div>
    </footer><!--/#footer-->
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>   
    <script src="js/wow.min.js"></script>
	<script src="js/main.js"></script>
  </body>
</html>