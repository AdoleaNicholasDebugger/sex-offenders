-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2020 at 01:10 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crime_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(5) DEFAULT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(2, '123', '123'),
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `alert_tbl`
--

CREATE TABLE `alert_tbl` (
  `id` int(5) NOT NULL,
  `Reg_No` varchar(29) NOT NULL,
  `pic` tinyblob DEFAULT NULL,
  `comment` varchar(19) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `alert_tbl`
--

INSERT INTO `alert_tbl` (`id`, `Reg_No`, `pic`, `comment`) VALUES
(1, 'cdvcs', 0x696e6368617267655f636f6d706c61696e5f64657461696c73312e706870, ' cdcwefw'),
(2, 'gyuhjnbvk', 0x686561646c6f67696e2e706870, ' huk'),
(3, 'jnbkj', 0x6f6666696369616c5f6c6f67696e2e706870, 'vuj'),
(4, 'adole', 0x6f6666696369616c5f6c6f67696e2e706870, 'vuj'),
(5, 'jnbkj', 0x5f513541393636392e4a5047, 'huhuuiyi'),
(6, 'adole', 0x434f44455f4f465f434f4e445543542e6d64, 'oi89ii');

-- --------------------------------------------------------

--
-- Table structure for table `citizens_register`
--

CREATE TABLE `citizens_register` (
  `cid` int(5) NOT NULL,
  `First_name` varchar(19) DEFAULT NULL,
  `Other_Names` varchar(19) DEFAULT NULL,
  `Gender` varchar(19) DEFAULT NULL,
  `Complexion` varchar(29) DEFAULT NULL,
  `Facial_Mark` varchar(29) DEFAULT NULL,
  `Height` varchar(29) DEFAULT NULL,
  `State` varchar(29) DEFAULT NULL,
  `LGA` varchar(29) DEFAULT NULL,
  `Home_address` varchar(29) DEFAULT NULL,
  `PlaceOfBirth` varchar(29) DEFAULT NULL,
  `Photo` tinyblob DEFAULT NULL,
  `dat` varchar(19) DEFAULT NULL,
  `MotherName` varchar(19) DEFAULT NULL,
  `FatherName` varchar(29) DEFAULT NULL,
  `parentsResidentialAddress` varchar(75) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `foreigners_register`
--

CREATE TABLE `foreigners_register` (
  `id` int(5) NOT NULL,
  `Firstname` varchar(19) DEFAULT NULL,
  `othernames` varchar(19) DEFAULT NULL,
  `countryorigin` varchar(19) DEFAULT NULL,
  `stateResident` varchar(29) DEFAULT NULL,
  `LGAresident` varchar(29) DEFAULT NULL,
  `residentialadress` varchar(29) DEFAULT NULL,
  `permitNo` varchar(29) DEFAULT NULL,
  `phot` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `graph`
--

CREATE TABLE `graph` (
  `id` int(5) NOT NULL,
  `category` varchar(19) DEFAULT NULL,
  `count` int(19) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `graph`
--

INSERT INTO `graph` (`id`, `category`, `count`) VALUES
(1, 'Murder', 4),
(2, 'Militancy', 11),
(3, 'Robbery', 3),
(4, 'Rape', 4),
(5, 'Terrorism', 3);

-- --------------------------------------------------------

--
-- Table structure for table `station_report`
--

CREATE TABLE `station_report` (
  `id` int(5) NOT NULL,
  `stationcode` varchar(19) DEFAULT NULL,
  `divisioncode` varchar(19) DEFAULT NULL,
  `caseIPO` varchar(19) DEFAULT NULL,
  `bio` varchar(500) DEFAULT NULL,
  `SuspectAddress` varchar(29) DEFAULT NULL,
  `reportdate` varchar(29) DEFAULT NULL,
  `report` varchar(75) DEFAULT NULL,
  `crimecategory` varchar(29) DEFAULT NULL,
  `chargedtocourt` varchar(29) DEFAULT NULL,
  `Photo` tinyblob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `station_report`
--

INSERT INTO `station_report` (`id`, `stationcode`, `divisioncode`, `caseIPO`, `bio`, `SuspectAddress`, `reportdate`, `report`, `crimecategory`, `chargedtocourt`, `Photo`) VALUES
(1, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"jude\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Murder', 'Yes', 0x686f6d652e706870),
(2, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Murder', 'Yes', 0x686f6d652e706870),
(3, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Murder', 'Yes', 0x686f6d652e706870),
(4, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Murder', 'Yes', 0x686f6d652e706870),
(5, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Murder', 'Yes', 0x686f6d652e706870),
(6, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Murder', 'Yes', 0x686f6d652e706870),
(7, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Murder', 'Yes', 0x686f6d652e706870),
(8, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Murder', 'Yes', 0x686f6d652e706870),
(9, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Murder', 'Yes', 0x686f6d652e706870),
(10, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Murder', 'Yes', 0x686f6d652e706870),
(11, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Murder', 'Yes', 0x686f6d652e706870),
(12, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Murder', 'Yes', 0x686f6d652e706870),
(13, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Militancy', 'Yes', 0x686f6d652e706870),
(14, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Militancy', 'Yes', 0x686f6d652e706870),
(15, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Militancy', 'Yes', 0x686f6d652e706870),
(16, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Militancy', 'Yes', 0x686f6d652e706870),
(17, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Militancy', 'Yes', 0x686f6d652e706870),
(18, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Militancy', 'Yes', 0x686f6d652e706870),
(19, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Militancy', 'Yes', 0x686f6d652e706870),
(20, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Robbery', 'Yes', 0x686f6d652e706870),
(21, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Robbery', 'Yes', 0x686f6d652e706870),
(22, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Rape', 'Yes', 0x686f6d652e706870),
(23, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Rape', 'Yes', 0x686f6d652e706870),
(24, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Rape', 'Yes', 0x686f6d652e706870),
(25, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Terrorism', 'Yes', 0x686f6d652e706870),
(26, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Terrorism', 'Yes', 0x686f6d652e706870),
(27, '45', '104', '3423', '    {\r\n  \"status\": true,\r\n  \"message\": \"BVN resolved\",\r\n  \"data\": {\r\n    \"first_name\": \"NICHOLAS\"\r\n    \"last_name\": \"ADOGO\",\r\n    \"dob\": \"30-May-85\",\r\n    \"formatted_dob\": \"1985-05-30\",\r\n    \"mobile\": \"08174799314\", \r\n    \"bvn\": \"22285581195\"\r\n  },\r\n  \"meta\": {\r\n    \"calls_this_month\": 9,\r\n    \"free_calls_left\": 1\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'fev vt3y3 sfwd dhjwg3uyg3 wdyu3jh', 'Rape', 'Yes', 0x686f6d652e706870),
(28, '2', '104', '3423', '    {\r\n  \"status\": false,\r\n  \"message\": \"Your balance is not enough to fulfill this request\",\r\n  \"meta\": {\r\n    \"calls_this_month\": 10,\r\n    \"free_calls_left\": 0\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'noi', 'Militancy', 'Yes', 0x686f6d652e706870),
(29, '222855', '104', '3423', ' \r\n  \"status\": false,\r\n  \"message\": \"Your balance is not enough to fulfill this request\",\r\n  \"meta\": {\r\n    \"calls_this_month\": 10,\r\n    \"free_calls_left\": 0\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'noi', 'Militancy', 'Yes', 0x686f6d652e706870),
(30, '222855811', '104', '3423', ' \r\n  \"status\": false,\r\n  \"message\": \"Your balance is not enough to fulfill this request\",\r\n  \"meta\": {\r\n    \"calls_this_month\": 10,\r\n    \"free_calls_left\": 0\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'noi', 'Militancy', 'Yes', 0x686f6d652e6a7067),
(31, '222855811', '104', '3423', ' \r\n  \"status\": false,\r\n  \"message\": \"Your balance is not enough to fulfill this request\",\r\n  \"meta\": {\r\n    \"calls_this_month\": 10,\r\n    \"free_calls_left\": 0\r\n  }\r\n}', 'plot sjfgyebhjgsu hegfue', '03/06/2011 22:25:02', 'noi', 'Militancy', 'Yes', 0x5f513541393633392e4a5047);

-- --------------------------------------------------------

--
-- Table structure for table `wanted`
--

CREATE TABLE `wanted` (
  `crimeid` int(5) NOT NULL,
  `Firstname` varchar(19) DEFAULT NULL,
  `othernames` varchar(19) DEFAULT NULL,
  `charges` varchar(29) DEFAULT NULL,
  `phot` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`password`);

--
-- Indexes for table `alert_tbl`
--
ALTER TABLE `alert_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `citizens_register`
--
ALTER TABLE `citizens_register`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `foreigners_register`
--
ALTER TABLE `foreigners_register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `graph`
--
ALTER TABLE `graph`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `station_report`
--
ALTER TABLE `station_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wanted`
--
ALTER TABLE `wanted`
  ADD PRIMARY KEY (`crimeid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
