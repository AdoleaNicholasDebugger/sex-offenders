A Pen created at CodePen.io. You can find this one at http://codepen.io/innerstorm/pen/nagFi.

 Best viewed in Chrome.

Design is from Bojana Cakic's dribbble shot.
http://dribbble.com/shots/911652-Transparent-organic-form

* background image is from lorempixel.com,
* icons are from Bojana's psd, embedded in css.
* Helvetica is replaced with Open Sans Condensed

Hope you like it :)