<?php

#Author Don Nicho

# Main menu


setcookie("user","");
setcookie("pass","");







include('index.html');



</script>