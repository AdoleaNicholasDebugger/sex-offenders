<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">

<?php
include '../config/dbconfig.php'
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>NACOSS e-Voting </title>
<link rel="stylesheet" href="style.css" type="text/css" />
<script language='JavaScript' type='text/JavaScript'>
<!--
function validate() {
	if(document.form1.query.value=='')
		{
		alert('input your Reg_No');
		return false;
		}
          else	{
		return true;
			}
}
//-->



</script>
<style type="text/css">
<!--
.style1 {
	color: #0000FF;
	font-weight: bold;
}
.btn {
	-webkit-box-shadow:rgba(0,0,0,0.2) 0 1px 0 0;
	-moz-box-shadow:rgba(0,0,0,0.2) 0 1px 0 0;
	box-shadow:rgba(0,0,0,0.2) 0 1px 0 0;
	border-bottom-color:#333;
	border:1px solid #61c4ea;
	background-color:#7cceee;
	border-radius:5px;
	-moz-border-radius:5px;
	-webkit-border-radius:5px;
	color:#333;
	font-family:'Verdana',Arial,sans-serif;
	font-size:14px;
	text-shadow:#b2e2f5 0 1px 0;
	padding:5px
}
.style4 {color: #990000; font-weight: bold; }
.style5 {color: #FF0000}
.style6 {color: #0000FF}
-->
</style>
</head>
<body>
<div id="header">
<label></label>
</div>
<div></div>
 
<div id="body">

	<table width="80%" border="1">
	<tr><img src="logo.jpg"></tr>
    <tr>
    <th colspan="7"><span class="style1">Crime Tracking </span><span class="style6">...
     
    </span>
    </tr>
    <tr>
	
	 <td><span class="style4">Firstname</span></td>
    <td><span class="style4">othernames</span></td>
    <td><span class="style4">countryorigin</span></td>
	<td><span class="style4">stateResident</span></td>
	<td><span class="style4">LGAresident</span></td>
    <td><span class="style4">residentialadress</span></td>
	<td><span class="style4">permitNo</span></td>
    </tr>
    <?php
	
	error_reporting(E_ALL ^ E_NOTICE);
	$query=$_POST["query"];
	
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');

$query=mysql_real_escape_string($_GET['query']);

 
	$sql="SELECT * from foreigners_register WHERE Firstname='$query'";
	$result_set=mysql_query($sql);
	
	while($row=mysql_fetch_array($result_set))
	
	
	{
	$Firstname = $row["Firstname"]; 
	$othernames = $row["othernames"]; 
	$countryorigin = $row["countryorigin"]; 
	$stateResident = $row["stateResident"]; 
	$LGAresident = $row["LGAresident"]; 
	
	$residentialadress = $row["residentialadress"]; 
	$permitNo = $row["permitNo"]; 
	
	?>
        <tr>
		<td><?php echo $row['Firstname'] ?></td>
        <td><?php echo $row['othernames'] ?></td>
        <td><?php echo $row['countryorigin'] ?></td>
		<td><?php echo $row['stateResident'] ?></td>
        <td><?php echo $row['LGAresident'] ?></td>
		<td><?php echo $row['residentialadress'] ?></td>
        <td><?php echo $row['permitNo'] ?></td>
       
        </tr>
        <?php
	}
	?>
    </table>
   
</div>
</body>
</html>






